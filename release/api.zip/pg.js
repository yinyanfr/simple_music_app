const moment = require("moment")

console.log(moment().format())
console.log(moment("2017-12-15T13:38:21-08:00"))
console.log(moment())
