const uuid = require("uuid");

console.log(uuid())