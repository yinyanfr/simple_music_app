export default {
    "logopage": {
        "title": "Christophe Roche",
        "subtitle": "app musique",
        "start": "Commencer"
    }
}
