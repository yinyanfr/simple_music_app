export default {
    "logopage": {
        "title": "Music Player",
        "subtitle": "lorem ipsum",
        "start": "Get Started"
    }
}

