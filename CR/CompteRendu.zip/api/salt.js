// please note that this is not the same salt that i use on my server
module.exports = "bluesymphony"
